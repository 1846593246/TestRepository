package com.dao.impl;


import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;


@Component
public class UserDaoImpl {
    public  UserDaoImpl(){
        System.out.println("UserDaoImpl的构造方法被调用");
    }
}
